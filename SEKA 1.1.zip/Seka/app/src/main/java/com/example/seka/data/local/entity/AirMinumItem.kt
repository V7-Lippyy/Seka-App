package com.example.seka.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "air_minum_items")
data class AirMinumItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val tanggal: Date = Date(),
    val jumlahGelas: Int = 0,
    val targetGelas: Int = 8,
    val ukuranGelas: Int = 250, // ml
    val pengingat: Boolean = true,
    val intervalPengingat: Int = 3, // Interval pengingat dalam jam (default 3 jam)
    val waktuPengingatTerakhir: Date? = null, // Waktu terakhir kali notifikasi dikirim
    val waktuGelasTerakhir: Date? = null, // Waktu terakhir kali menambah gelas

    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
)