package com.example.seka.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

enum class TodoUrgency {
    HIGH, MEDIUM, LOW
}

@Entity(tableName = "todo_items")
data class TodoItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val date: Date,
    val dueDate: Date? = null, // Tenggat waktu (opsional)
    val urgency: TodoUrgency,
    val isCompleted: Boolean = false,
    val dailyReminder: Boolean = false, // Pengingat harian
    val dueDateReminder: Boolean = false, // Pengingat untuk tenggat waktu
    val dueDateReminderDays: Int = 1, // Berapa hari sebelum tenggat akan diingatkan
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
)