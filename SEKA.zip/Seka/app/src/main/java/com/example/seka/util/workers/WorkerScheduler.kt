package com.example.seka.util.workers

import android.content.Context
import androidx.work.*
import com.example.seka.util.workers.KeuanganWorker.Companion.WORK_NAME as KEUANGAN_WORK_NAME
import com.example.seka.util.workers.TabunganWorker.Companion.WORK_NAME as TABUNGAN_WORK_NAME
import com.example.seka.util.workers.TodoReminderWorker.Companion.WORK_NAME as TODO_WORK_NAME
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Kelas untuk mengelola penjadwalan semua worker notifikasi.
 */
@Singleton
class WorkerScheduler @Inject constructor(
    private val workManager: WorkManager
) {
    /**
     * Jadwalkan semua worker yang diperlukan.
     */
    fun scheduleAllWorkers() {
        scheduleTodoReminderWorker()
        scheduleTabunganWorker()
        scheduleKeuanganWorker()
    }

    /**
     * Jadwalkan worker untuk pengingat to-do.
     * Berjalan setiap hari pada pukul 8 pagi.
     */
    fun scheduleTodoReminderWorker() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
            .build()

        val todoReminderRequest = PeriodicWorkRequestBuilder<TodoReminderWorker>(
            repeatInterval = 24,
            repeatIntervalTimeUnit = TimeUnit.HOURS
        )
            .setConstraints(constraints)
            .build()

        workManager.enqueueUniquePeriodicWork(
            TODO_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            todoReminderRequest
        )
    }

    /**
     * Jadwalkan worker untuk pemeriksaan tabungan.
     * Berjalan setiap hari pada pukul 9 pagi.
     */
    fun scheduleTabunganWorker() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
            .build()

        val tabunganWorkerRequest = PeriodicWorkRequestBuilder<TabunganWorker>(
            repeatInterval = 24,
            repeatIntervalTimeUnit = TimeUnit.HOURS
        )
            .setConstraints(constraints)
            .setInitialDelay(1, TimeUnit.HOURS) // Berselang 1 jam dari todo worker
            .build()

        workManager.enqueueUniquePeriodicWork(
            TABUNGAN_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            tabunganWorkerRequest
        )
    }

    /**
     * Jadwalkan worker untuk pemeriksaan keuangan.
     * Berjalan setiap hari pada pukul 10 pagi.
     */
    fun scheduleKeuanganWorker() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
            .build()

        val keuanganWorkerRequest = PeriodicWorkRequestBuilder<KeuanganWorker>(
            repeatInterval = 24,
            repeatIntervalTimeUnit = TimeUnit.HOURS
        )
            .setConstraints(constraints)
            .setInitialDelay(2, TimeUnit.HOURS) // Berselang 2 jam dari todo worker
            .build()

        workManager.enqueueUniquePeriodicWork(
            KEUANGAN_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            keuanganWorkerRequest
        )
    }

    /**
     * Batalkan semua worker yang terjadwal.
     */
    fun cancelAllWorkers() {
        workManager.cancelUniqueWork(TODO_WORK_NAME)
        workManager.cancelUniqueWork(TABUNGAN_WORK_NAME)
        workManager.cancelUniqueWork(KEUANGAN_WORK_NAME)
    }

    companion object {
        /**
         * Jadwalkan semua worker secara statis untuk digunakan di BootReceiver.
         */
        fun scheduleAllWorkersStatic(context: Context) {
            val workManager = WorkManager.getInstance(context)

            // Todo Reminder Worker
            val todoReminderRequest = PeriodicWorkRequestBuilder<TodoReminderWorker>(
                repeatInterval = 24,
                repeatIntervalTimeUnit = TimeUnit.HOURS
            ).build()

            workManager.enqueueUniquePeriodicWork(
                TODO_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                todoReminderRequest
            )

            // Tabungan Worker
            val tabunganWorkerRequest = PeriodicWorkRequestBuilder<TabunganWorker>(
                repeatInterval = 24,
                repeatIntervalTimeUnit = TimeUnit.HOURS
            )
                .setInitialDelay(1, TimeUnit.HOURS)
                .build()

            workManager.enqueueUniquePeriodicWork(
                TABUNGAN_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                tabunganWorkerRequest
            )

            // Keuangan Worker
            val keuanganWorkerRequest = PeriodicWorkRequestBuilder<KeuanganWorker>(
                repeatInterval = 24,
                repeatIntervalTimeUnit = TimeUnit.HOURS
            )
                .setInitialDelay(2, TimeUnit.HOURS)
                .build()

            workManager.enqueueUniquePeriodicWork(
                KEUANGAN_WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                keuanganWorkerRequest
            )
        }
    }
}