package com.example.seka.ui.screens.tabungan

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.seka.util.FileUtils
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabunganDetailScreen(
    navController: NavController,
    tabunganId: Long,
    viewModel: TabunganDetailViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val dateFormatter = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID"))
    var showDatePicker by remember { mutableStateOf(false) }
    val currencyFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID"))
    val context = LocalContext.current

    // Image picker launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.updateImageUri(it) }
    }

    // Menu popup untuk pilihan gambar
    var showImagePickerMenu by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.isSaved) {
        if (uiState.isSaved) {
            navController.navigateUp()
        }
    }

    LaunchedEffect(uiState.error) {
        if (uiState.error != null) {
            // Handle error, e.g., show a snackbar
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(if (tabunganId == -1L) "Tambah Tabungan" else "Edit Tabungan")
                },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.saveTabungan() }) {
                        Icon(Icons.Default.Save, contentDescription = "Simpan")
                    }
                }
            )
        }
    ) { padding ->
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (uiState.error != null) {
                    Text(
                        text = uiState.error!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }

                // Image picker section
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.outline,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { showImagePickerMenu = true },
                    contentAlignment = Alignment.Center
                ) {
                    if (uiState.imagePath != null) {
                        // Tampilkan gambar jika tersedia
                        val file = File(uiState.imagePath!!)
                        if (file.exists()) {
                            FileUtils.loadBitmapFromFile(uiState.imagePath!!)?.let { bitmap ->
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = "Gambar barang",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                    } else {
                        // Tampilkan placeholder jika tidak ada gambar
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAPhoto,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Tambahkan Gambar")
                        }
                    }
                }

                if (showImagePickerMenu) {
                    AlertDialog(
                        onDismissRequest = { showImagePickerMenu = false },
                        title = { Text("Pilih Sumber Gambar") },
                        text = {
                            Column {
                                TextButton(
                                    onClick = {
                                        imagePickerLauncher.launch("image/*")
                                        showImagePickerMenu = false
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Image, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Galeri")
                                }

                                if (uiState.imagePath != null) {
                                    TextButton(
                                        onClick = {
                                            viewModel.updateImageUri(null)
                                            showImagePickerMenu = false
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Hapus Gambar", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showImagePickerMenu = false }) {
                                Text("Batal")
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = uiState.nama,
                    onValueChange = { viewModel.updateNama(it) },
                    label = { Text("Nama Barang") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = if (uiState.hargaTarget == 0.0) "" else uiState.hargaTarget.toString(),
                    onValueChange = { viewModel.updateHargaTarget(it) },
                    label = { Text("Harga Target (Rp)") },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = if (uiState.tabunganTerkumpul == 0.0) "" else uiState.tabunganTerkumpul.toString(),
                    onValueChange = { viewModel.updateTabunganTerkumpul(it) },
                    label = { Text("Tabungan Awal (Rp)") },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Cicilan Harian",
                    style = MaterialTheme.typography.titleMedium
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = if (uiState.cicilanJumlah == 0.0) "" else uiState.cicilanJumlah.toString(),
                    onValueChange = { viewModel.updateCicilanJumlah(it) },
                    label = { Text("Jumlah Cicilan per Hari (Rp)") },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (uiState.hargaTarget > 0 && uiState.cicilanJumlah > 0) {
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Estimasi: ${uiState.estimasiHari} hari untuk mencapai target",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = uiState.kategori,
                    onValueChange = { viewModel.updateKategori(it) },
                    label = { Text("Kategori") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { showDatePicker = true }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CalendarToday, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (uiState.targetDate != null)
                                "Target Tanggal: ${dateFormatter.format(uiState.targetDate!!)}"
                            else
                                "Pilih Target Tanggal (Opsional)",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }

                if (uiState.targetDate != null) {
                    TextButton(
                        onClick = { viewModel.updateTargetDate(null) },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Hapus Tanggal")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Progress visualization if we're editing
                if (tabunganId != -1L && uiState.hargaTarget > 0) {
                    val progress = (uiState.tabunganTerkumpul / uiState.hargaTarget)
                        .coerceIn(0.0, 1.0)

                    Text(
                        text = "Status Tabungan",
                        style = MaterialTheme.typography.titleMedium
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = progress.toFloat(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(16.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Terkumpul: ${currencyFormat.format(uiState.tabunganTerkumpul)}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "${(progress * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }

                Button(
                    onClick = { viewModel.saveTabungan() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Simpan")
                }
            }
        }

        if (showDatePicker) {
            val datePickerState = rememberDatePickerState(
                initialSelectedDateMillis = uiState.targetDate?.time
                    ?: System.currentTimeMillis()
            )

            DatePickerDialog(
                onDismissRequest = { showDatePicker = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            datePickerState.selectedDateMillis?.let { millis ->
                                viewModel.updateTargetDate(Date(millis))
                            }
                            showDatePicker = false
                        }
                    ) {
                        Text("OK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDatePicker = false }) {
                        Text("Batal")
                    }
                }
            ) {
                DatePicker(state = datePickerState)
            }
        }
    }
}