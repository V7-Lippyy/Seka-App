package com.example.seka.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.seka.R
import com.example.seka.ui.navigation.Screen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable

data class FeatureItem(
    val title: String,
    val icon: ImageVector,
    val route: String,
    val description: String,
    val gradientColors: List<Color>
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(navController: NavController) {
    val features = listOf(
        FeatureItem(
            "To Do List",
            Icons.Rounded.CheckCircle,
            Screen.Todo.route,
            "Catat dan kelola tugas-tugas dengan prioritas",
            listOf(Color(0xFF42A5F5), Color(0xFF1976D2))
        ),
        FeatureItem(
            "Catatan",
            Icons.Rounded.Note,
            Screen.Note.route,
            "Simpan catatan penting",
            listOf(Color(0xFF66BB6A), Color(0xFF388E3C))
        ),
        FeatureItem(
            "Tabungan",
            Icons.Rounded.Savings,
            Screen.Tabungan.route,
            "Kelola tabungan untuk barang yang diinginkan",
            listOf(Color(0xFFFFA726), Color(0xFFF57C00))
        ),
        FeatureItem(
            "Keuangan",
            Icons.Rounded.MonetizationOn,
            Screen.Keuangan.route,
            "Lacak pemasukan dan pengeluaran",
            listOf(Color(0xFFEC407A), Color(0xFFC2185B))
        ),
        FeatureItem(
            "Ringkasan",
            Icons.Rounded.Summarize,
            Screen.Summary.route,
            "Ringkas teks panjang",
            listOf(Color(0xFF7E57C2), Color(0xFF512DA8))
        ),
        FeatureItem(
            "Parafrase",
            Icons.Rounded.Repeat,
            Screen.Paraphrase.route,
            "Ubah teks dengan makna sama",
            listOf(Color(0xFF26A69A), Color(0xFF00796B))
        ),
        FeatureItem(
            "Terjemahan",
            Icons.Rounded.Translate,
            Screen.Terjemahan.route,
            "Terjemahkan teks ke berbagai bahasa",
            listOf(Color(0xFF5C6BC0), Color(0xFF3949AB))
        ),
        FeatureItem(
            "SEKA AI",
            Icons.Rounded.SmartToy,
            Screen.SekaAI.route,
            "Asisten AI dengan fitur suara",
            listOf(Color(0xFFEF5350), Color(0xFFD32F2F))
        )
    )

    val scrollState = rememberScrollState()
    var isLoaded by remember { mutableStateOf(false) }
    var showSearchDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    // Banner images
    val bannerImages = listOf(
        "https://media-hosting.imagekit.io//23c34eb0fcb84f12/banner1.png?Expires=1837220164&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=RWkQrGmnCzJE~Dy0bHvNL1kZv-Hcy2AAgZbOBD4h7WDAxwEcOukgdlPOuE6uWANStCFzFkY~qb-0ejWzNpWyqmCNsU5tVrgFFjr7-TmSJ3ncPTIlw0qZYXYTShX1N99aljQBnbTqtr1J-w~MZDWIKb5BOA35dBAVDyPQ8KR8frQXg4SkKt5AvS-ARlFB~uQOs-Q4gDOQc5wQgmTFl0tc8np8pnEsjXuRBJRCFY8Q1cFUqaEhlfWhpV6FHFQW12yBV-ervTHEkqfJ1emQe3spQzse7Z4WN2uISLrxwir6GJibB0WA4-mjyTolaemxOc~FoOe0lqT3M7y-iXGkXeCTrQ__",
        "https://media-hosting.imagekit.io//4d02e20244b94f8b/banner1%20(1).png?Expires=1837222626&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=HFbfXlW5gW4PuQaoFABrhFb17bCKfvsp10wi6yNfu3lWEeoVhIaftZWln0dbqDv6jSVA1~yOKc2oIdSdblyf0uJfK996HYbx2Bn1iIVvNo9lp8lvaedJLbrMSd3On6x3Zw1rIpEK1zLAkF2k1oRjHb71g2DgW9DWXdkGTyT3NBUkOGsukB1T0QBOrZ9gyt633RjLjrwPpPnN3Y2P-dTdz5HBF86tWMOFpMhY6nIvJuqRhMoBr3nG2UzP9uGvAYD0-Qjv4lW7XrhXuppsPalyZaJRRBTDBy2tMSFMZnZCe2B19ehnfFXS2Zpxv9pFyd~r6EsahcAcXRQ~nNDB~hA4Xg__",
        "https://media-hosting.imagekit.io//c4572d61d62a4833/banner1%20(2).png?Expires=1837222628&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=RZxT5zQnm6xVgsnx0HQhL-PTBdM6yQCpJFrPiIUsYGRzuufrVti1lDwaxb~MqCF1DJEuDkopCdMSsYrcPeew5kq4JAhJt3DqTzpNoYJWc4LJKV5uAH0VBIZXWjGXs5r~GKu2uAwX9Ipn1-VVYFCxhFhi23V4Kq~FgV3ows2OySAlOX63028WxouElMTvtVgNJVnIOmrUP6LR~WJqLYKYIAhc9e8LBMai55Eyw8yrqp~DKrLDq3FuP2rIaPp6oX7A7d3vcmcMqRj~zP4IGqxZMs61l3CshUFwvl9Uzbk5Nq9KeDohkE3s9ZbrB2bjYjM6udKd7jVMPeCOLvpV47tpgg__"
    )

    // Filtered features based on search
    val filteredFeatures = remember(searchQuery) {
        if (searchQuery.isBlank()) features
        else features.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
                    it.description.contains(searchQuery, ignoreCase = true)
        }
    }

    // Pager state for the banner carousel
    val pagerState = rememberPagerState(pageCount = { bannerImages.size })
    val coroutineScope = rememberCoroutineScope()

    // Auto-scroll the banner
    LaunchedEffect(key1 = Unit) {
        delay(100)
        isLoaded = true

        while (true) {
            delay(3000) // Change image every 3 seconds
            coroutineScope.launch {
                pagerState.animateScrollToPage(
                    page = (pagerState.currentPage + 1) % bannerImages.size
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    // Logo based on theme
                    val isDarkTheme = isSystemInDarkTheme()
                    val logoResource = if (isDarkTheme) R.drawable.logowhite else R.drawable.logo
                    Image(
                        painter = painterResource(id = logoResource),
                        contentDescription = "Logo SEKA",
                        modifier = Modifier.height(100.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                actions = {
                    // Search button
                    IconButton(onClick = { showSearchDialog = true }) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Cari fitur"
                        )
                    }
                    // Notification icon removed
                }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Image Carousel
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxWidth()
                ) { page ->
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(bannerImages[page])
                            .crossfade(true)
                            .build(),
                        contentDescription = "Banner $page",
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1920f / 600f)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Divider(
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )

                Text(
                    text = " Pilih Fitur ",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp),
                    color = MaterialTheme.colorScheme.primary
                )

                Divider(
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Features Grid
            filteredFeatures.forEachIndexed { index, feature ->
                AnimatedVisibility(
                    visible = isLoaded,
                    enter = fadeIn(tween(durationMillis = 300, delayMillis = 100 * index)) +
                            slideInVertically(
                                tween(durationMillis = 300, delayMillis = 100 * index),
                                initialOffsetY = { it / 2 }
                            )
                ) {
                    EnhancedFeatureCard(
                        feature = feature,
                        onClick = { navController.navigate(feature.route) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Search Dialog
    if (showSearchDialog) {
        AlertDialog(
            onDismissRequest = {
                showSearchDialog = false
                searchQuery = ""
            },
            title = { Text("Cari Fitur") },
            text = {
                Column {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Masukkan kata kunci...") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                focusManager.clearFocus()
                                showSearchDialog = false
                            }
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Show search results in the dialog
                    if (searchQuery.isNotBlank()) {
                        LazyColumn(
                            modifier = Modifier.heightIn(max = 300.dp)
                        ) {
                            items(filteredFeatures) { feature ->
                                ListItem(
                                    headlineContent = { Text(feature.title) },
                                    supportingContent = { Text(feature.description) },
                                    leadingContent = {
                                        Icon(
                                            imageVector = feature.icon,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    modifier = Modifier.clickable {
                                        showSearchDialog = false
                                        searchQuery = ""
                                        navController.navigate(feature.route)
                                    }
                                )
                                Divider()
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showSearchDialog = false
                    }
                ) {
                    Text("Tutup")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnhancedFeatureCard(feature: FeatureItem, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 2.dp,
            pressedElevation = 8.dp,
            hoveredElevation = 4.dp
        ),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        brush = Brush.linearGradient(feature.gradientColors)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = feature.icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = feature.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = feature.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Icon(
                imageVector = Icons.Rounded.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}